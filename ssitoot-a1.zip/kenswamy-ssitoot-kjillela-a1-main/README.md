# kenswamy-ssitoot-kjillela-a1

# a1-release

## Part 1: Birds, heuristics, and A*

The algorithm used here is A* with number of displaced positions as the heuristic. The data structure used for the entirety of the algorithm is priority queue.
The evaluation function which is a summation of cost from start state to the current state (gs) and heuristic cost which is the cost from current state to the goal state (hs). In terms of its representation in the code, gs gets incremented by 1 each time the successors of that specific state are found and heuristic (hs) is the just the sum of number of displaced elements in the given state when compared to the goal state. Another possible heuristic that can be considered in this approach is Manhattan distance. But when compared, Manhattan proves to be costlier and hence not admissible.

The algorithm initially starts by saving all the immediate successor states along with the total cost (gs + hs). This cost is the is the basis for priority and the one with least cost moves gets picked and its own successor states are added to the priority queue along with their respective costs. This process continues until the goal state it found.

----------------------------------------------------------------------------------------------------------------------------------------------------------------
#Part 2: The 2022 Puzzle

#Question1 - Branching Factor:
Branching factor basically means the number of out-degrees that a particular state can have. In this particular problem, the branching factor is the total number of successor states that a particular state can have. So, as per the question, we can move the rows left and right, columns can be moved up and down. Other than that we could move the outer rows and columns clockwise and anti-clockwise and also the inner rows and columns clockwise and anti-clockwise.
So here the matrix is of size 5 X 5. Hence, total 20 up, down, right, left moves and 4 inner and outer clockwise and anti-clockwise moves. This sums up to 24 possible successor states. So the branching factor for this question is 24.

#Question2 - Number of states that BFS would require if solution was found in 7 moves

BFS starts with the first state and explores all the states at the present depth before going ahead to the next level. So in this case BFS would explore 24 different states before moving ahead to the next depth. The number of explored states would definitely depend on the operations chosen. So if there would be 7 moves for row, column or circle, then BFS would roughly explore 24^7 (24 raised to 7).

#Code Implementation:

We have implemented A* algorithm with a heuristic function which uses Manhattan Distance. Other than that we have used threshold values after which the search stops and comes back to the first state and starts searching again and skips the 1st state from the successor function which it took the previous time. This will help in the cases where the solution is not found even after a lot of successor states. Also we have written code to prevent the states going to the already visited states. We planned on using another heuristic which would return the number of displaced tiles but it seemed that the heuristic is not that efficient for this particular problem.

So, the main heuristic in the developed code is the manhattan distance between the number and its goal position. The heuristic function returns the minimum value of the manhattan distance and the wrap around manhattan distance. So whichever successor state promises best manhattan value, it choses that particular state and goes ahead.

#Scope:

The code requires another heuristic which could help in making efficient decisions while choosing the successor functions since in some cases the code is not able to find solutions.

----------------------------------------------------------------------------------------------------------------------------------------------------------------
#Part 3:

Finding the shortest route between start city and end city.

#Intialization:
Initialized variable and the paths from where the data is to be loaded.

#Priority Queue:
For this problem we have used the priority queue to determine that the smallest heuristic path so that it is considered in top priority and then the larger heuristic path later.

City Map and Getting Directions:
Reading the file, stripping and splitting the contents to get the latitude, longitude, distance in miles, speed limits and highways route names.

Finding the max length segment:
Finds the route with the fewest number of road segments.

Finding the max speed:
Gets the max speed

Path Segment:
Examining the element that pops from the priority queue based on its heuristic. If the city is the end city where we need to reach then returning the variables. If not then check for the neighbouring cities. Using the hueristic we are calculating the best possible segments.

Finding the Shortest Path:
Similar to the above function, using the hueristic we are calculating the best and shortest possible path.

Finding the Fastest route:
Using the hueristic, we calculate the fastest time.

Finding the delivery time:
Finding the fastest possible delivery time using the hueristic function.

references: 
Geek for Geeks
Youtube
